import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PersonTypeListComponent } from './person-types/person-type-list/person-type-list.component';
import { PersonListComponent } from './persons/person-list/person-list.component';

const routes: Routes = [
  {
    path: 'persons',
    component: PersonListComponent, 
  },
  {
    path: 'persontypes',
    component: PersonTypeListComponent,   
  },
];

@NgModule({
  imports: [ RouterModule.forRoot(routes) ],
  exports: [ RouterModule ]
})
export class AppRoutingModule {}
