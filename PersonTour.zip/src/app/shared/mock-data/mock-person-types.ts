import { PersonType} from '../models/person-type';

export const PERSON_TYPES: PersonType[] = [
  { id: 12, name: 'Employee' },
  { id: 13, name: 'Customer' },
  { id: 14, name: 'Contractor' },
  { id: 15, name: 'Vendor' },
  { id: 16, name: 'Management' },
  { id: 17, name: 'Marketing Leads' },
  { id: 18, name: 'Entertainer' },
  { id: 19, name: 'Chefs' },
  { id: 20, name: 'Security' }
];
