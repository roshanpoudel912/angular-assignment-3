export interface PersonType {
  id: number;
  name: string;
}
