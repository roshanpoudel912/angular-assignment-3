import { Component, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, NgForm, Validators } from '@angular/forms';
import { PersonType } from 'src/app/shared/models/person-type';
import { PersonTypeService } from 'src/app/shared/services/person-type.service';

@Component({
  selector: 'app-person-type-list',
  templateUrl: './person-type-list.component.html',
  styleUrls: ['./person-type-list.component.css'],
})
export class PersonTypeListComponent {
  // cached person type list
  personTypes: PersonType[] = [];
  
  constructor(private personTypeService: PersonTypeService) { }

  ngOnInit(): void {
    this.getPersonTypes();
  }

  getPersonTypes(): void {
    this.personTypeService
      .getPersonTypes()
      .subscribe((personTypesResult) => (this.personTypes = personTypesResult));
  }

  delete(personType: PersonType): void {
    this.personTypeService
      .deletePersonType(personType.id)
      .subscribe(
        (_) =>
          (this.personTypes = this.personTypes.filter((h) => h !== personType))
      );
  }

  add(name: string): void {
    name = name.trim();
    if (!name) { return; }
    this.personTypeService.addPersonType({ name } as PersonType)
      .subscribe(personType => {
        this.personTypes.push(personType);
      });
  }
}
