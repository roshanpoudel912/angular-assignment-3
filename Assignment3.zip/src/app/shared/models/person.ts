export interface Person {
  personId: number;
  status: number;
  firstName: string;
  lastName: string;
  phoneNumber: string;
  emailAddress: string;
  birthDate: string;
  personTypeId:number;
}
